import { Component } from "react";

class App extends Component{
    state={
        conditions: false
    }
    toggleConditions=()=>{
        this.setState(function(){
            return{
                conditions:!this.state.conditions
            }
        },
        function(){
            console.log(this.state.conditions)
        })
    }
    render(){
            return <div>
                 <label htmlFor="">Terms and conditions
                        <input type="checkbox" onChange={this.toggleConditions} />
                 </label>
                 {this.state.conditions && <fieldset>
                 <legend>Terms and Conditions</legend>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsum error aliquid omnis repellendus facilis vero quia corporis? Blanditiis nulla impedit porro nisi, dolores iusto voluptatem eos unde adipisci repudiandae et!
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo, repellendus earum. Laborum nihil inventore nostrum doloribus animi voluptas porro nesciunt magni perferendis, modi earum assumenda magnam consectetur odit itaque. Earum?
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quibusdam perferendis aliquid recusandae cupiditate, natus ea facere nemo numquam nulla iure provident quidem sunt atque minima necessitatibus esse ipsa repellat ipsam.
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero fuga in commodi ullam consectetur! Maiores, quidem. Sed repudiandae dolorum non dignissimos nisi tempore molestias. Placeat corrupti reiciendis sint distinctio dolores?
                    </p>
                 </fieldset>}
            </div>
                
        }
    }
export default App