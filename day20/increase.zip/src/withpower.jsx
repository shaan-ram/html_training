import { Component } from "react"


let withPower = (OriginalComp)=>{
    return class TempComp extends Component{
        state ={
            power:0
        }
        increasePower=()=>{
            this.setState({
                power: this.state.power +1
            }) 
        }
        render(){
            return <OriginalComp power={this.state.power} increasePower={this.increasePower} />
        }
    }
}

export default withPower;