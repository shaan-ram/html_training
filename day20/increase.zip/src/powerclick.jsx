import { Component } from "react";
import withPower from "./withpower";


class PowerClick extends Component{
    render(){
        return <div style={{border:"5px solid red", margin:"10px", padding:"15px"}}>
            <h4>Power: {this.props.power}</h4>
            <button className="btn btn-warning" onClick={this.props.increasePower}>Increase</button>
        </div>
    }      
}
export default withPower(PowerClick);