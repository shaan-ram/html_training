import { Component } from "react";
import Powerclick from "./powerclick";
import Powersilde from "./powersilde";


class App extends Component{
    render(){
        let mystyle = {color:"grey", textAlign:"center", margin:"10px"}
        return <div>
                <h2 style={{...mystyle}} >Application Component</h2>
                <Powerclick/>
                <Powersilde/>
                
        </div>
    }
}
export default App