import { Component } from "react";
import ChildComp from "./childcomp";

class App extends Component{
    state ={
        power: 0,
        title: "Component Communications"
    }
    increasePower=()=>{
        this.setState({
            power: this.state.power +1
        })
    }
    decreasePower=()=>{
        this.setState({
            power: this.state.power -1
        })
    }
    changeChild=(ntitle)=>{
        this.setState({
            title: ntitle
        })
    }
    render(){
        return( <div>
            <h2>Power:{this.state.power}</h2>
            <h2>Title:{this.state.title}</h2>
           <button onClick={this.increasePower}>Increase Power</button>
           <button onClick={this.decreasePower}>Decrease Power</button>
           <ChildComp power={this.state.power} changeChild={this.changeChild}/>
           <ChildComp power={this.state.power} changeChild={this.changeChild}/>
            </div>)
               
    }
    
}
 
export default App;