import { createRef, Component } from "react";

class ChildComp extends Component{
    elm = createRef();
    render(){
        return <div>
                <h2>Power:{this.props.power}</h2>
                <input type="text" ref={this.elm} onChange={()=> this.props.changeChild(this.elm.current.value) + (this.elm.current.value)}/>
            </div>
    }
}

export default ChildComp;