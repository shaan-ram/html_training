import { Component } from "react";
import { style } from "./extstyle";
import client from "./client.module.css";
import "./style/external.css";

class App extends Component{
    mystyle = style;
    
    render(){
        let istyle = {backgroundColor : "yellow" , color : "black", margin : "10px", padding : "10px"};
        return <div>
                    <h1>App Component</h1>
                    <article style={ this.mystyle }>
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Exercitationem distinctio facere quaerat, repudiandae, veniam earum blanditiis iusto consectetur amet nemo doloremque placeat eius. Voluptates, libero quis facere est a laboriosam?
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Exercitationem distinctio facere quaerat, repudiandae, veniam earum blanditiis iusto consectetur amet nemo doloremque placeat eius. Voluptates, libero quis facere est a laboriosam?
                    </article>
                    <article style={ istyle }>
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Exercitationem distinctio facere quaerat, repudiandae, veniam earum blanditiis iusto consectetur amet nemo doloremque placeat eius. Voluptates, libero quis facere est a laboriosam?
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Exercitationem distinctio facere quaerat, repudiandae, veniam earum blanditiis iusto consectetur amet nemo doloremque placeat eius. Voluptates, libero quis facere est a laboriosam?
                    </article>
                    <article style={ {...this.mystyle, backgroundColor:"blue"}  }>
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Exercitationem distinctio facere quaerat, repudiandae, veniam earum blanditiis iusto consectetur amet nemo doloremque placeat eius. Voluptates, libero quis facere est a laboriosam?
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Exercitationem distinctio facere quaerat, repudiandae, veniam earum blanditiis iusto consectetur amet nemo doloremque placeat eius. Voluptates, libero quis facere est a laboriosam?
                    </article>
                    <hr />
                    <article className="box">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda harum velit natus iusto rerum quisquam eum placeat quia aliquid accusantium consequatur ipsa, voluptatum praesentium corporis atque voluptates illum porro ex?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus, labore repudiandae. Dolores omnis saepe aliquid voluptate quisquam excepturi, ut veritatis. Vero a delectus, eos unde sit culpa itaque molestias excepturi?
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Esse, quaerat impedit eveniet saepe accusantium iste debitis maxime asperiores sit similique officiis ab pariatur aliquid porro nostrum repudiandae ad repellendus deleniti.
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Iure commodi, aliquid incidunt nisi quia ea deleniti velit eveniet at atque placeat hic quod quo veritatis doloribus blanditiis. Minus, sint provident?
                    </article>
                    <article className={client.box}>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Assumenda harum velit natus iusto rerum quisquam eum placeat quia aliquid accusantium consequatur ipsa, voluptatum praesentium corporis atque voluptates illum porro ex?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus, labore repudiandae. Dolores omnis saepe aliquid voluptate quisquam excepturi, ut veritatis. Vero a delectus, eos unde sit culpa itaque molestias excepturi?
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Esse, quaerat impedit eveniet saepe accusantium iste debitis maxime asperiores sit similique officiis ab pariatur aliquid porro nostrum repudiandae ad repellendus deleniti.
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Iure commodi, aliquid incidunt nisi quia ea deleniti velit eveniet at atque placeat hic quod quo veritatis doloribus blanditiis. Minus, sint provident?
                    </article>
                </div>
        
     }
};

export default App