import Users from "./user.component"

let App = ()=>{
    return <div>
        <h2 style={{textAlign: "center"}}>Heroes List</h2>
        <Users/>
    </div>
}
export default App
