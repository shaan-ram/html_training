function Superman(){
    return <div>
        <h2 style={{textAlign: "center"}}>Superman</h2>
    
    </div>
}
export default Superman;