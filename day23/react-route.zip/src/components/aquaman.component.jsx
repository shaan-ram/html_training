function Aquaman(){
    return <div>
        <h2 style={{textAlign: "center"}}>Aqua Man</h2>
       
    </div>
}
export default Aquaman;