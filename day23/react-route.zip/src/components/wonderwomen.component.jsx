
function WonderWomen(){
    return <div>
        <h2 style={{textAlign: "center"}}>Wonder Women</h2>

    </div>
}
export default WonderWomen;
