import data from "../data.json"
import "../myStyle.css"
import {useParams} from "react-router-dom"
let Details = ()=>{
    let params = useParams()
    return <div>
       {
        data.heroes.map((val,idx)=>{
            if(params.id === val.id){
                return <div key={val.id} className="box">
                    <h4>Name : {val.name}</h4>
                    <h4>Power Stats</h4>
                    <h3>Power: {val.powerstats.power}</h3>
                    <h3>Speed: {val.powerstats.speed}</h3>
                    <h4>Biography</h4>
                    <p>{val.biography["full-name"]}, {val.biography["place-of-birth"]},{val.biography["publisher"]}</p>
                    <h4>gender: {val.appearance["gender"]}</h4>
                    <h4>Race: {val.appearance["race"]}</h4>
                    </div>
            }
            
        })
       }
    </div>
}
export default Details