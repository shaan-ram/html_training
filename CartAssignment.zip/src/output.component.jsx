import "./mystyle.css"
import { useEffect, useRef } from "react"
import { useState } from "react"
import axios from "axios"

var name = Array([])
var qty = Array([])
var price = Array([])
var total=0
var nme=""
let OutputComp = ()=>{
    let elm=useRef()
    let[users,setUser] = useState([])
    let [ncart, updateCart] = useState({ name : '', qty : '', price : ''});
    let refresh = ()=>{
        axios.get("http://localhost:3030/data").then(res => {
            setUser(res.data);
        })
    }
    let clickHandler = (evt)=>{
       
        updateCart({...ncart, qty : Number(evt.target.value)})
    }
    let editCart = (hid)=>{
        axios.get("http://localhost:3030/getData/"+hid).then(res => {
            updateCart(res.data);
            nme=res.data.hero
            name.push(nme)
            price.push(res.data.price)
            qty.push(ncart.qty)
            total+=ncart.qty*res.data.price
        })
    }
    useEffect(()=>{
        refresh()
    },[])
    return <div>
                {
                users.map((val,idx)=>{
                    return  <div key={val._id} className="cont">
                                <p>TITLE : {val.hero}</p>
                                <p>NAME: {val.name}</p>
                                <p>PRICE: {val.price}</p>
                                <form action="#">
                                <label  id="qty">QUANTIY: 
                                    <input ref={elm} type="number" onInput={(evt)=> clickHandler(evt)} className="qty" min="0" required/>
                                </label>
                                <input type="submit" onClick={()=> editCart(val._id)} className="btn btn-warning" value="ADD TO CART"/>
                                </form>
                               
                            </div>
                })
                }
                <div className="cart">
                    <p style={{textAlign:"center"}}>Cart</p>
                    <hr />
                    {
                    name.map((val,idx)=>{
                        return val!=""?<p style={{fontSize:"20px",padding:"15px"}} key={idx}>Title:  {val}</p>:<h2></h2> 
                    })
                }{
                    qty.map((val,idx)=>{
                        return val!=""?<p style={{fontSize:"20px",padding:"15px"}} key={idx}>Qty:  {val}</p>:<h2></h2>   
                    })
                }
                {
                    price.map((val,idx)=>{
                        return val!=""?<p style={{fontSize:"20px",padding:"15px"}} key={idx}>Price:  {val}</p>:<h2></h2>   
                    })
                }
                    <div>
                        <p>Total:{total}</p>
                    </div>
                </div>
                </div>
   
}
export default OutputComp