import OutputComp from "./output.component"
import "./mystyle.css"

let App = ()=>{
    return <div>
        <p className="header">Avengers list</p>
        <OutputComp/>
    </div>
}
export default App
