function FlashComp(){
    return <div>
        <h2 style={{textAlign: "center"}}>Flash</h2>
    </div>
}
export default FlashComp;
