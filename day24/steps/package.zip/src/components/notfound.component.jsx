function NotFound(){
    return <div>
        <h2 style={{textAlign: "center"}}>Not found</h2>
   
    </div>
}
export default NotFound