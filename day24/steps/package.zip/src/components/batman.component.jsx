import { useNavigate } from "react-router-dom";
import WonderWomen from "./wonderwomen.component";


function Batman(){
let womenNav = useNavigate();
    return <div>
        <h2>Batman</h2>
        <button onClick={ ()=> womenNav("/wonderwomen", { replace : false })}>Navigate to Wonder women</button>
        <WonderWomen/>
       </div>
}
export default Batman;