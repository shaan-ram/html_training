import { useReducer } from "react";
let UseEffectComp = (props)=> {
let reducerFun=(state,action)=>{
        switch(action.type){
            case "FIRST_NAME": return({...state,firstname:"Shaan"})
            case "LAST_NAME": return({...state,lastname:"Raam"})
            default: return state
        }
    }
    let[state,dispatch]=useReducer(reducerFun,{ firstname : " "})
    
    return <div>
                <h2>Use Reducer Hook</h2>
                <h3>Firstname:{state.firstname}</h3>
                <button onClick={()=>dispatch({type: "FIRST_NAME"})}>Update</button>
                <h3>Lastname:{state.lastname}</h3>
                <button onClick={()=>dispatch({type: "LAST_NAME"})}>Update</button>
            </div>
}
export { UseEffectComp };