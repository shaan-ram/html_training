import { UseEffectComp } from "./useReducerComp";
 
let App = ()=> {
   
 return <div>
                <UseEffectComp/>
        </div>
    }
export default App;