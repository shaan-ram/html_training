import GrandparentComp from "./grandparent.comp";
 
let App = ()=> {
   
 return <div>
                <GrandparentComp/>
        </div>
    }
export default App;