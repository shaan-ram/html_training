import { useEffect } from "react";

let UseEffectComp = (props)=> {
let power=props.state.power

    useEffect(()=>{
        console.log("Mount")
    },[])
        useEffect(()=>{
            console.log("update")
        },[ props.state.version])

        useEffect(()=>{
            return()=>{
            console.log("unmounted")
        }
    },[])
   
    
    return <div>
                 <h2>Use Reducer Hook</h2>
                 <h3>Power is : { power }</h3> 
                 <h3>Version is : { props.version }</h3>
                 <h3>Rating is : { props.rating }</h3> 
            </div>
}
export { UseEffectComp };
 