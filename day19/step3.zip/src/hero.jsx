import { Component } from "react";

class Hero extends Component{
    rating = 25
    render(){
        return <div>
                {/* <h2>{this.props.title.toUpperCase().length}</h2>
                <h3>{this.props.version+10}</h3> */}

                    <h2>{this.props.title+" | version: "+(this.props.version)}</h2>
                    
                <h3>{this.rating}</h3> 
                <ol>{
                    this.props.list.map((val,idx)=>{
                        return <li key= {idx}>{val}</li>
                    })
                    }
                </ol>
                <button onClick={()=>{
                    this.rating = this.rating + 1;
                    console.log(this.rating);
                    this.forceUpdate()
                }}> Change Version
                </button>

        </div> 

    }
}
export default Hero