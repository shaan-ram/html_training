import { Component } from "react";
import Hero from "./hero"

class App extends Component{
    avengers = ['Ironman','Captain America','Hulk','Spiderman']
    justiceleague =['Batman','Superman','Aquaman','Wonder woman']
    caheroes =['ShaktiMan','ChootaBheem',]
    render(){
        return <div>
            <Hero list ={this.avengers}      version={1} title ="Avenger"></Hero>
            <Hero list ={this.justiceleague} version={2} title ="Justice League"></Hero>
            <Hero list ={this.caheroes}      version={3} title ="CA Heroes"></Hero>
        </div>
    }
}
export default App