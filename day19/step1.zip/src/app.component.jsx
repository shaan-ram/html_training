// function App(){
//     return <h1>Welcome!!</h1>
// };
// export {App}  //OR export default App

import { Component } from "react";
class App extends Component{
    render(){
        return <h1>Welcome!!</h1>
    }
}
export {App}