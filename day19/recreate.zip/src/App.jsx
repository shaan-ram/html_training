import { Component } from "react";
import Header1 from "./header";
import Main from "./main";
import Product from "./product";
import Products from "./products";
import Footer from "./footer";
class App extends Component{
    render(){
        return <div>
            <Header1/>
            <Main/>
            <Product/>
            <Products/>
            <Footer/>
        </div>
    }
}
export default App