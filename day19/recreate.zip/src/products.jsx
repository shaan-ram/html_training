import { Component } from "react";
import Product from "./product";
class Products extends Component{
    render(){
        return <div>
                <Product/>
                <Product/>
                <Product/>
                <Product/>
                <Product/>
                <Product/>
                <Product/>
                <Product/>
        </div>
       
    }
}
export default Products
