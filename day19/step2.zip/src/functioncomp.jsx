import { FunComp } from "react"

let FunComp(){
           console.log("Function Component was rendered", Math.random())
           return <div>
                    <h1>Pure Child Component |  power is { this.prop.power } | version:{this.prop.version}</h1>
                    </div>
          
      }

      export default FunComp;