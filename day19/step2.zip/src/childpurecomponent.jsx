import { Component } from "react";

class PureChildComp extends Component{
     render(){
            console.log("Component was rendered", Math.random())
            return <div>
             <h1>Pure Child Component |  power is { this.prop.power } | version:{this.prop.version}</h1>
               
            </div>
           }
       }

       export default PureChildComp;