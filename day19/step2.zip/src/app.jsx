import { PureComponent } from "react";
import { Component } from "react";
import ChildComp from "./child.component";

class App extends Component{
    changePower = (evt) =>{
        this.setState({
            power: Range(this.state.power + 1)
        })
    }
    setVersionTo=()=>{
        this.setState({
            version: 100
        })
    }
    render(){
        return <div>
            {/* <ChildComp title="Shaan" power={100} version={1}></ChildComp> */}
              <button onClick={this.increasePower }>increasePower</button>
                <button onClick={this.setVersionTo }>Set Version</button>
                <ChildComp version={this.state.version} power={this.state.power}></ChildComp>
                <PureComponent version={this.state.version} power={this.state.power}></PureComponent>
        </div>
    }
}

export default App