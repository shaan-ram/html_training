import { Component, createRef } from "react";
import PropTypes from "prop-types";
import { PureComponent } from "react";

class ChildComp extends Component{
//     static defaultProps ={
//         title : "Default title",
//         power: 0,
//         version: 0
//     }
//     render(){
//         return <div>
//             <h3>Title: {this.props.title}</h3>
//             <h3>Power: {this.props.power}</h3>
//             <h3>Version: {this.props.version}</h3>
//         </div>
//     }
// }
    elm = createRef()
        state ={
            title: "Default Title",
            power : this.props.power

        }
        // increasePower = ()=>{
        //     this.setState({
        //         power : this.state.power + 1
        //     });
        // }
        setPower = (evt) =>{
            this.setState({
                power: Number(evt.target.value)
            })
        }
        changePower = (evt) =>{
            this.setState({
                power: Range(this.state.power + 1)
            })
        }
        setVersionTo=(evt)=>{
            this.setState({
                version: Number(evt.target.value)
            })
        }
        increasePower = ()=>{
            this.setState(function(currentState, currentProp){
                return{
                power : this.state.power + 1
                }
            }, function(){
                console.log(this.state.power);
            })
        }
        
        render(){
            console.log("Component was rendered", Math.random())
            return <div>
                {/* <h2>Child Component</h2>
                <h3>Title : {this.state.title}</h3>
                <h3>Version: {this.props.version}</h3>
                <h3>Power: {this.state.power}</h3>
                {/* <button onClick={ this.increasePower.bind(this)}>Increase Power</button> */}
                {/* <button onClick={ this.increasePower }>Increase Power</button>
                <button onClick={()=>{
                    this.setState({
                        title: "Changed"
                    });
                }}> Change Title</button>
                <br />
                <input type="number" ref={ this.elm } />
                <button onClick={ this.setPower }> Reset Power</button>
                <input type="range" ref={ this.elm } />
                <button onClick={ this.changePower }> Change Power</button> */} 

                <h1>Child Component |  power is { this.prop.power } | version:{this.prop.version}</h1>
               
            </div>
        }
    }

// ChildComp.defaultProps ={
//     title : "Default title",
//     power: 0,
//     version: 0
// }

export default ChildComp;