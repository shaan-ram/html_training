const express = require("express")
const mongoose = require("mongoose")
const session = require("client-sessions")
const csurf = require("csurf");

let app = express();

app.use(express.urlencoded({extended : true}));
app.use(session({
    cookieName: "valtech",
    secret: "jhgfrvnmi23487jk3uhj3rham4bjbh4wiu8rghjhsk00shiiymshdhiukfj",
    duration: 30 * 60 * 1000,
    activeDuration: 10 * 60 * 1000,
    cookie:{
        ephemeral: true
    }
   
}))
app.use(csurf({  sessionKey : "valtech" }));
// app.use(function(req, res, next){
//     if(req.valtech && req.valtech.user){
//         User.findOne({ email : req.valtech.user.email }, function(err, user){
//             if(user){
//                 // req.user = user;
//                 req.valtech.user = req.registeredUser = user;
//                 // delete req.user.password;
//                 // res.locals.user = req.user;
//             }
//             next();
//         })
//     }else{
//         next();
//     }
// })
// let requireLogin = function(req, res, next){
//     if(!req.registeredUser){
//         res.redirect("/login");
//     }else{
//         next();
//     }
// }


let Schema = mongoose.Schema
let ObjectId = Schema.ObjectId
let User = new mongoose.model("User",({
    id: ObjectId,
    firstname: String,
    lastname: String,
    email: {type:String,unique: true},
    password: String
}))

const string_mongo ="mongodb+srv://admin:lJZcuuF2ce8idvpP@cluster0.ijqvhi3.mongodb.net/valtechdb?retryWrites=true&w=majority"
mongoose.connect(string_mongo).then((res)=>console.log("Connected"))
.catch((err)=>console.log("Error",error))


app.get("/",(req,res)=>{
    res.render("home.pug",{ csrfToken : req.csrfToken() })
})

app.get("/login",(req,res)=>{
    res.render("login.pug",{ csrfToken : req.csrfToken() })
})

app.post("/login",(req,res)=>{
  User.findOne({email: req.body.email}, function(error,user){
    if(!user){
        res.render("login.pug", {
            error: "no username by that credentials"
        })
    }else{
        if(req.body.password === user.password){
            req.valtech.user = user;
            res.redirect("/profile");
        }else{
            res.render("login.pug",{
                error: "invalid email or password"
            })
        }
    }
  })
})


app.post("/register",(req,res)=>{
   var user = new User({
    firstname: req.body.firstname,
    lastname: req.body.lastname,
    email: req.body.email,
    password: req.body.password
   })

   user.save(function(error){
    let clienterror = "";
    if(error){
        if(error.code === 11000){
            clienterror = "error"
        }
        else{
            clienterror = "Something went wrong"
        }
        res.render("register.pug",{
            clienterror
        })
    }else{
        res.redirect("/profile")
        console.log("done")
    }
    })
})

app.get("/profile",(req,res)=>{
    res.render("profile.pug",{ csrfToken : req.csrfToken() })
})
app.get("/register",(req,res)=>{
    res.render("register.pug")
})

app.get("/template",(req,res)=>{
    res.render("template.pug")
})

app.get("/logout",(req,res)=>{
    req.valtech.reset()
    res.redirect("/")
})

app.listen(4545,"localhost",function(error){
    if(error){
        console.log("Error",error)
    }else{
        console.log("localhost is now live on 4545")
    }
})