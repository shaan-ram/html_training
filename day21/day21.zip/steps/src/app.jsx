import { Component } from "react"
import UseStateObjComp from "./useStateObj.comp"
import  UseStateAssignmentComp from "./useStateObj.comp"

class App extends Component{
    
    render(){
        return <div>
           <h2>HOOKS</h2>
         
           < UseStateAssignmentComp/>
        </div>
    }
}
    export default App